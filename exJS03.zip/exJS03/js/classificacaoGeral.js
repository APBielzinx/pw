export default function classificacaoGeral(classificacaoPb,classificacaoPn,classificacaoPs,classificacaoPob1,classificacaoPob2,classificacaoPob3){

    console.log(`\n a quantidade de alunos com o peso baixo é ${classificacaoPb}`)
    console.log(`\n a quantidade de alunos com o peso normal é ${classificacaoPn}`)
    console.log(`\n a quantidade de alunos com o soberepeso é ${classificacaoPs}`)
    console.log(`\n a quantidade de alunos com o obesidade grau 1 é ${classificacaoPob1}`)
    console.log(`\n a quantidade de alunos com o obesidade grau 2 é ${classificacaoPob2}`)
    console.log(`\n a quantidade de alunos com o obesidade grau 3 é ${classificacaoPob3}`)
   
}
