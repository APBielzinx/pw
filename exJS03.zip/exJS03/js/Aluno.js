
export class Aluno{
  nome
  altura
  peso
  idade
  imc

   get nome(){
    return this.nome
   }

   set nome(nome){
      this.nome = nome
      
   }

   get altura(){
    return this.altura
   }

   set altura(altura){
      this.altura = altura
   }

   get peso(){
    return this.peso
   }

   set peso (peso){
    this.peso = peso
   }

   get idade(){
    return this.idade
  
  }

   set idade(idade){
    this.idade = idade

   }
  
   get imc(){

    return this.imc

   }

   set imc(imc){
    this.imc = imc
   }


   }
