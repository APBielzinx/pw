import { Aluno } from "./Aluno.js"

export default function retornaAlunos(){

    var aluno01 = new Aluno()
       aluno01.nome ="kaue"
       aluno01.idade = 17
       aluno01.peso = 60
       aluno01.altura = 1.80
       aluno01.imc = null
  
       var aluno02 = new Aluno()
       aluno02.nome ="Gabriel"
       aluno02.idade = 22
       aluno02.peso = 20
       aluno02.altura = 1.99
       aluno02.imc = null

       var aluno03 = new Aluno()
       aluno03.nome ="Kauan"
       aluno03.idade = 13
       aluno03.peso = 60
       aluno03.altura = 1.50
       aluno03.imc = null

       var aluno04 = new Aluno()
       aluno04.nome ="Richard"
       aluno04.idade = 19
       aluno04.peso = 80
       aluno04.altura = 1.68
       aluno04.imc = null
   
       var aluno05 = new Aluno()
       aluno05.nome ="Rafael"
       aluno05.idade = 17
       aluno05.peso = 70
       aluno05.altura = 1.70
       aluno05.imc = null
   
       var aluno06 = new Aluno()
       aluno06.nome ="claudio"
       aluno06.idade = 12
       aluno06.peso = 50
       aluno06.altura = 1.69
       aluno06.imc = null
    
       var aluno07= new Aluno()
       aluno07.nome ="julia"
       aluno07.idade = 32
       aluno07.peso = 79
       aluno07.altura = 1.76
       aluno07.imc = null
    
       var aluno08= new Aluno()
       aluno08.nome ="João"
       aluno08.idade = 18
       aluno08.peso = 90
       aluno08.altura = 1.89
       aluno08.imc = null

       var aluno09= new Aluno()
       aluno09.nome ="pedro"
       aluno09.idade = 52
       aluno09.peso = 69
       aluno09.altura = 1.79
       aluno09.imc = null
    
       var aluno10= new Aluno()
       aluno10.nome ="julio"
       aluno10.idade = 15
       aluno10.peso = 88
       aluno10.altura = 1.99
       aluno10.imc = null
  
       var aluno11= new Aluno()
       aluno11.nome ="jubair"
       aluno11.idade = 11
       aluno11.peso = 77
       aluno11.altura = 1.66
       aluno11.imc = null
  
       var aluno12= new Aluno()
       aluno12.nome ="claudemir"
       aluno12.idade = 18
       aluno12.peso = 120
       aluno12.altura = 1.78
       aluno12.imc = null

       var aluno13= new Aluno()
       aluno13.nome ="ana"
       aluno13.idade = 20
       aluno13.peso = 78
       aluno13.altura = 1.68
       aluno13.imc = null

       var aluno14= new Aluno()
       aluno14.nome ="larissa"
       aluno14.idade = 14
       aluno14.peso = 70
       aluno14.altura = 1.79
       aluno14.imc = null
    
       var aluno15= new Aluno()
       aluno15.nome ="Matheus"
       aluno15.idade = 16
       aluno15.peso = 60
       aluno15.altura = 1.70
       aluno15.imc = null

       var aluno16= new Aluno()
       aluno16.nome ="juliana"
       aluno16.idade = 18
       aluno16.peso = 80
       aluno16.altura = 1.99
       aluno16.imc = null

       var aluno17= new Aluno()
       aluno17.nome ="juliano"
       aluno17.idade = 12
       aluno17.peso = 50
       aluno17.altura = 1.69
       aluno17.imc = null
    
       var aluno18= new Aluno()
       aluno18.nome ="fernando"
       aluno18.idade = 10
       aluno18.peso = 100
       aluno18.altura = 1.50
       aluno18.imc = null
    
       var aluno19= new Aluno()
       aluno19.nome ="claudinha"
       aluno19.idade = 14
       aluno19.peso = 59
       aluno19.altura = 1.89
       aluno19.imc = null
    
       var aluno20= new Aluno()
       aluno20.nome ="Giovanni"
       aluno20.idade = 19
       aluno20.peso = 80
       aluno20.altura = 1.60
       aluno20.imc = null
    
   var listaAlunos = [aluno01,aluno02,aluno03,aluno04,aluno05,aluno06,aluno07,aluno08,aluno09,aluno10,
                      aluno11,aluno12,aluno13,aluno14,aluno15,aluno16,aluno17,aluno18,aluno19,aluno20]

    return listaAlunos

}